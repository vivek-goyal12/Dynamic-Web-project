

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.beans.Statement;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

/**
 * Servlet implementation class LoginServlet
 */
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		boolean success = false;
        String username =  request.getParameter("username");
        String password = 	request.getParameter("password");
        String query = "SELECT * FROM tbluser WHERE username = ? AND password = ?";		Connection conn = null;
        PreparedStatement stmt  = null;
		PrintWriter display = response.getWriter();
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			conn =  DriverManager.getConnection("jdbc:mysql://localhost:3306/user", "root", "root");
			stmt = conn.prepareStatement(query);
	        stmt.setString(1, username);
	        stmt.setString(2, password);
			ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                  //Login Successful if Match is found
                  success = true;
            } 
		} catch (Exception e) {
             e.printStackTrace();
		} finally {
           try {
               stmt.close();
               conn.close();
           } catch (Exception e) {}
		}
        if(success) {
        	response.sendRedirect("successLogin.jsp");
        }
		else {
			display.println("Login Failed");
			
		}
	}

}
